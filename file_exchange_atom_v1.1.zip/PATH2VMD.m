%% The VMD path on your computer
function PATH2VMD = PATH2VMD()

% Add your own path to VMD here. Note that you might need a '\' to skipe
% spaces

PATH2VMD = '/Applications/VMD\ 1.9.2.app/Contents/MacOS/startup.command'; 

