%% import_gmx_index.m
% * This function import an gromacs index file and sends the groups indexes to the calling workspace
% * Apparently not finished!!!

function import_gmx_index(filename)

disp('Apparently not finished!!!')
